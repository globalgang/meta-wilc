#ifndef APLISTITEM_H
#define APLISTITEM_H

#include "common.h"

class APListItem : public QStandardItem
{
public:
    APListItem(QString mac_addr = "", QString ip_addr = "");
    ~APListItem();

protected:
    QVariant data(int role = Qt::UserRole + 1) const;
    void setData(const QVariant &value, int role = Qt::UserRole + 1);

private:
    QString m_mac;
    QString m_client_ip;
};

#endif // APLISTITEM_H
