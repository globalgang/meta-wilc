#ifndef P2PLISTMODEL_H
#define P2PLISTMODEL_H

#include "common.h"

class P2PListModel : public QStandardItemModel
{
public:
    P2PListModel();
};

#endif // P2PLISTMODEL_H
