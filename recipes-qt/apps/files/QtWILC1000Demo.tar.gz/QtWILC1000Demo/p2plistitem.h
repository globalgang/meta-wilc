#ifndef P2PLISTITEM_H
#define P2PLISTITEM_H

#include "common.h"

class P2PListItem : public QStandardItem
{
public:
    P2PListItem(QString peer_mac = "", QString peer_name = "");
    ~P2PListItem();

protected:
    QVariant data(int role = Qt::UserRole + 1) const;
    void setData(const QVariant &value, int role = Qt::UserRole + 1);

private:
    QString m_peer_mac;
    QString m_peer_name;
    QString m_peer_ip;
    bool m_status;
};

#endif // P2PLISTITEM_H
