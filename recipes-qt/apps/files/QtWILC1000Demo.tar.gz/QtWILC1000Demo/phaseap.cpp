#include "phaseap.h"
#include <QProcess>
#include <iostream>

PhaseAP::PhaseAP(QObject *parent) : QObject(parent)
{
    mAPListModel.clear();

    mAPSSID = parent->findChild<QObject *>("APModePlate")->
            findChild<QObject *>("APModePlateRow1")->
            findChild<QObject *>("APModeSSID");

    mAPType = parent->findChild<QObject *>("APModePlate")->
            findChild<QObject *>("APModePlateRow1")->
            findChild<QObject *>("APModeType");

    mAPPassword = parent->findChild<QObject *>("APModePlate")->
            findChild<QObject *>("APModePlateRow1")->
            findChild<QObject *>("APModePassword");

    mAPHWMode = parent->findChild<QObject *>("APModePlate")->
            findChild<QObject *>("APModePlateRow2")->
            findChild<QObject *>("APModeHWMode");

    mAPChannel = parent->findChild<QObject *>("APModePlate")->
            findChild<QObject *>("APModePlateRow2")->
            findChild<QObject *>("APModeChannel");

    QObject::connect(this, SIGNAL(sendAPListModel(QVariant)), parent, SLOT(receiveListModel(QVariant)));
    QObject::connect(this, SIGNAL(sendEventResult(QVariant,QVariant)), parent, SLOT(receiveEventResult(QVariant, QVariant)));
}

PhaseAP::~PhaseAP()
{

}

void PhaseAP::receiveEvent(QString event)
{
    std::cout<<"Receive AP Event : " + event.toStdString()<<std::endl;

    if (!event.compare("AP")) {
        doKillProcess();
        doInit();

        emit sendInitComplete();
        emit sendAPListModel(QVariant::fromValue(&mAPListModel));

        mState = IDLE;
    } else if(!event.compare("SET")) {
        //test Code
//        if(0) {
//            QString addr = "a0:e4:53:ca:05:8e";
//            mAPListModel.appendRow(new APListItem(addr));
//            QModelIndexList indexList = mAPListModel.match(
//                        mAPListModel.index(0, 0, QModelIndex()),
//                        MAC,
//                        addr,
//                        -1);

//            mAPListModel.item(indexList.at(0).row())->setData("192.168.0.2", CLIENTIP);
//            return;
//        }

        if(mState == IDLE) {
            doConfigureAP();
            doConfigureDHCP();
            doParse();
        }
        doSet();        
        mState = SCAN_SET;
    } else if(!event.compare("STOP")) {
        doKillProcess();
        doInit();

        mAPListModel.clear();

        mState = IDLE;
    } else if(!event.compare("DISCONNECT")) {
        doDisconnect();
    } else {
        doUpdate(event.contains("udhcpd_parse"));
    }
}

void PhaseAP::doInit()
{
    QProcess proc;
    bool bState = false;

    proc.start("/bin/sh -c \"echo 1 > /proc/sys/net/ipv4/ip_forward\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] Step 2"<<std::endl;
    } else {
        bState = true;
    }

    if(bState) {
        bState = false;
        proc.start("iptables -F");
        if(!proc.waitForFinished(10000)) {
            std::cout<<"[Error] Step 3"<<std::endl;
        } else {
            bState = true;
        }
    }

    if(bState) {
        bState = false;
        proc.start("iptables -A FORWARD -i eth0 -o wlan0 -j ACCEPT");
        if(!proc.waitForFinished(10000)) {
            std::cout<<"[Error] Step 4"<<std::endl;
        } else {
            bState = true;
        }
    }

    if(bState) {
        bState = false;
        proc.start("iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT");
        if(!proc.waitForFinished(10000)) {
            std::cout<<"[Error] Step 5"<<std::endl;
        } else {
            bState = true;
        }
    }

    if(bState) {
        bState = false;
        proc.start("iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE");
        if(!proc.waitForFinished(10000)) {
            std::cout<<"[Error] Step 6"<<std::endl;
        } else {
            bState = true;
        }
    }

    if(bState) {
        bState = false;
        proc.start("ifconfig wlan0 up");
        if(!proc.waitForFinished(10000)) {
            std::cout<<"[Error] Step 7"<<std::endl;
        } else {
            bState = true;
        }
    }

    if(bState) {
        bState = false;
        proc.start("ifconfig wlan0 192.168.0.1");
        if(!proc.waitForFinished(10000)) {
            std::cout<<"[Error] Step 8"<<std::endl;
        } else {
            bState = true;
        }
    }

    proc.close();
}

void PhaseAP::doConfigureAP()
{
    QProcess proc;

    QString hostConf;

    hostConf.append("interface=wlan0\n");
    hostConf.append("driver=nl80211\n");
    hostConf.append("ctrl_interface=/var/run/hostapd\n");
    hostConf.append(QString("ssid=%1\n").arg(mAPSSID->property("inputText").toString()));
    hostConf.append("dtim_period=2\n");
    hostConf.append("beacon_int=100\n");
    hostConf.append(QString("channel=%1\n").arg(mAPChannel->property("itemLabelText").toString()));
    hostConf.append(QString("hw_mode=%1\n").arg(mAPHWMode->property("itemLabelText").toString()));
    hostConf.append("max_num_sta=8\n");
    hostConf.append("ap_max_inactivity=300\n");
    hostConf.append("ieee80211n=1\n");
    hostConf.append("auth_algs=1\n");

    if(!mAPType->property("itemLabelText").toString().contains("OPEN")) {
        if(mAPType->property("itemLabelText").toString().contains("WPA/WPA2")) {
            hostConf.append("wpa=3\n");
        } else if(mAPType->property("itemLabelText").toString().contains("WPA2")) {
            hostConf.append("wpa=2\n");
        } else if(mAPType->property("itemLabelText").toString().contains("WPA1")) {
            hostConf.append("wpa=1\n");
        }

        hostConf.append(QString("wpa_passphrase=%1\n").arg(mAPPassword->property("inputText").toString()));
        hostConf.append("wpa_key_mgmt=WPA-PSK\n");

        if(hostConf.contains("wpa=1")) {
            hostConf.append("wpa_pairwise=TKIP\n");
        } else if(hostConf.contains("wpa=2")) {
            hostConf.append("rsn_pairwise=CCMP\n");
        } else if(hostConf.contains("wpa=3")) {
            hostConf.append("wpa_pairwise=TKIP CCMP\n");
            hostConf.append("rsn_pairwise=CCMP\n");
        }
    }

    std::cout<<hostConf.toStdString()<<std::endl;

    proc.start("/bin/sh -c \"cat /dev/null > /etc/temp_hostapd.conf\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureAP 1"<<std::endl;
    }

    proc.start(QString("/bin/sh -c \"echo \"\"\"%1\"\"\" > /etc/temp_hostapd.conf\"").arg(hostConf));
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureAP 2"<<std::endl;
    }

    proc.close();
}

void PhaseAP::doConfigureDHCP()
{
    QProcess proc;

    QString dhcpConf;

    dhcpConf.append("start 192.168.0.20\n");
    dhcpConf.append("end 192.168.0.50\n");

    dhcpConf.append("interface wlan0\n");

    dhcpConf.append("opt dns 10.168.5.38\n");
    dhcpConf.append("opt subnet 255.255.255.0\n");
    dhcpConf.append("opt router 192.168.0.1\n");
    dhcpConf.append("opt lease 86400\n");

    std::cout<<dhcpConf.toStdString()<<std::endl;

    proc.start("/bin/sh -c \"cat /dev/null > /etc/temp_udhcpd.conf\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureDHCP 1"<<std::endl;
    }

    proc.start(QString("/bin/sh -c \"echo \"\"\"%1\"\"\" > /etc/temp_udhcpd.conf\"").arg(dhcpConf));
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureDHCP 2"<<std::endl;
    }

    proc.close();
}

void PhaseAP::doSet()
{
    QProcess proc;

    proc.startDetached("/bin/sh -c \"hostapd -d /etc/temp_hostapd.conf > /var/log/hostapd.log\"");
    proc.waitForFinished(10000);

    proc.startDetached("/bin/sh -c \"udhcpd -f /etc/temp_udhcpd.conf > /var/log/udhcpd.log\"");
    proc.waitForFinished(10000);

    proc.close();
}

void PhaseAP::doParse()
{
    std::cout<<"doParse"<<std::endl;
    QProcess proc;
    proc.startDetached("/bin/sh -c \" tail -f /var/log/hostapd.log | "
                       "grep --line-buffered -e AP-STA-DISCONNECTED -e AP-STA-CONNECTED > "
                       "/var/log/hostapd_parse.log\"");
    if(proc.waitForFinished(10000)){}

    proc.startDetached("/bin/sh -c \" tail -f /var/log/udhcpd.log | "
                       "grep --line-buffered -e \'Sending ACK to\' > "
                       "/var/log/udhcpd_parse.log\"");
    if(proc.waitForFinished(10000)){}

    proc.close();
}

void PhaseAP::doUpdate(bool dhcp)
{
    std::cout<<"doUpdate"<<std::endl;
    QProcess proc;
    QString result;

    bool bState = false;

    if(!dhcp) {
        QString macAddr;
        QString ipAddr;
        QModelIndexList indexList;

        //Station Accept Event
        proc.start("tail -n 1 /var/log/hostapd_parse.log");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();

            if(result.contains("AP-STA-DISCONNECTED")) {
                std::cout<<"Delete item"<<std::endl;

                macAddr = result.remove(0, QString("wlan0: AP-STA-DISCONNECTED ").length());

                indexList.clear();

                indexList = mAPListModel.match(
                            mAPListModel.index(0, 0, QModelIndex()),
                            AP_MAC,
                            macAddr,
                            -1);
                if(!indexList.isEmpty() && indexList.size() > 0) {
                    std::cout<<"Delete item detail : " + macAddr.toStdString()<<std::endl;
                    mAPListModel.removeRow(indexList.at(0).row());
                }
            } else if (result.contains("AP-STA-CONNECTED")) {
                std::cout<<"Add item"<<std::endl;

                macAddr = result.remove(0, QString("wlan0: AP-STA-CONNECTED ").length());

                indexList.clear();

                indexList = mAPListModel.match(
                            mAPListModel.index(0, 0, QModelIndex()),
                            AP_MAC,
                            macAddr,
                            -1);

                if(!indexList.isEmpty() && indexList.size() > 0) {
                    return;
                }

                mAPListModel.appendRow(new APListItem(macAddr));
                bState = true;
                std::cout<<"Add item detail : " + macAddr.toStdString()<<std::endl;
            }
        }

        if(bState) {
            result.clear();
            std::cout<<"Add IP Address"<<std::endl;

            //Check arp table
            proc.start(QString("/bin/sh -c \"cat /proc/net/arp | grep %1\"").arg(macAddr));
            if(proc.waitForFinished(10000)) {
                result = proc.readAllStandardOutput();

                ipAddr = result.split(QRegExp("\\s")).first();

                std::cout<<"IP Address : " + ipAddr.toStdString()<<std::endl;

                if(!ipAddr.isEmpty() && !ipAddr.isNull()) {

                    indexList.clear();

                    indexList = mAPListModel.match(
                                mAPListModel.index(0, 0, QModelIndex()),
                                AP_MAC,
                                macAddr,
                                -1);

                    if(indexList.size() == 0) {
                        return;
                    }

                    mAPListModel.item(indexList.at(0).row())->setData(ipAddr, AP_IP);
                    std::cout<<"Add IP Address FIN"<<std::endl;
                }
            }
        }
    } else {
        std::cout<<"Add IP in dhcp process"<<std::endl;

        proc.start("tail -n 1 /var/log/udhcpd_parse.log");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();

            QString ipAddr = result.remove(0, QString("Sending ACK to ").length());

            if(ipAddr.isEmpty() || ipAddr.isNull()) {
                return;
            }

            std::cout<<"IP Address: " + ipAddr.toStdString()<<std::endl;

            QModelIndexList indexList = mAPListModel.match(
                        mAPListModel.index(0, 0, QModelIndex()),
                        AP_IP,
                        "",
                        -1);

            std::cout<<"Founded Item Count : " + QString::number(indexList.size()).toStdString()<<std::endl;

            if(indexList.size() > 0) {
                std::cout<<"Founded Item MAC : " + mAPListModel.item(indexList.at(0).row())->data(AP_MAC).toString().toStdString()<<std::endl;

                mAPListModel.item(indexList.at(0).row())->setData(ipAddr, AP_IP);
            }
        }
    }

    proc.close();
}

void PhaseAP::doDisconnect()
{
    //disconnect item
}

void PhaseAP::doKillProcess()
{
    QProcess proc;

    proc.start("killall hostapd");
    proc.waitForFinished(10000);

    proc.start("killall udhcpd");
    proc.waitForFinished(10000);

    proc.start("killall wpa_supplicant");
    proc.waitForFinished(10000);

    proc.start("killall tail");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/lib/misc/udhcpd.leases\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/udhcpd.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/udhcpd_parse.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/hostapd.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/hostapd_parse.log\"");
    proc.waitForFinished(10000);

    proc.close();
}
