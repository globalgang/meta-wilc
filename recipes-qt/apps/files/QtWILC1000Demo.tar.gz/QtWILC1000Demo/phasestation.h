#ifndef PHASESTATION_H
#define PHASESTATION_H

#include <QObject>
#include <QRegExp>

#include "stationlistmodel.h"
#include "stationlistitem.h"
#include "common.h"

class PhaseStation : public QObject
{
    Q_OBJECT
public:
    explicit PhaseStation(QObject *parent = 0);
    ~PhaseStation();

signals:
    void sendInitComplete();
    void sendEventResult(QVariant event, QVariant result);
    void sendStationListModel(QVariant model);

public slots:
    void receiveEvent(QString event);

private:
    void doInit();
    void doConfigure();
    void doParse();
    void doScan();
    void doScanResult(bool bDummy = false);
    void doConnect(bool bPassword = false);
    void doConnectResult();
    void doDisconnect();
    void doKillProcess();

private:
    StationListModel mStationListModel;
    QRegExp mSSID_Filter;

private:
    QObject *mStationList;
    QObject *mStationPSK;

private:
    State mState;
};

#endif // PHASESTATION_H
