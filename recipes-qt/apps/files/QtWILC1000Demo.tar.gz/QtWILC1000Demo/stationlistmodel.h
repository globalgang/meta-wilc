#ifndef STATIONLISTMODEL_H
#define STATIONLISTMODEL_H

#include "common.h"

class StationListModel : public QStandardItemModel
{
public:
    StationListModel();
};

#endif // STATIONLISTMODEL_H
