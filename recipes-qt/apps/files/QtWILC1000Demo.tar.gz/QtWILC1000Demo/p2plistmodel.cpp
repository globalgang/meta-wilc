#include "p2plistmodel.h"

P2PListModel::P2PListModel()
{
    QHash<int, QByteArray> roles;
    roles[P2P_MAC] = "peer_mac";
    roles[P2P_NAME] = "peer_name";
    roles[P2P_IP] = "peer_ip";
    roles[P2P_STATUS] = "peer_status";
    setItemRoleNames(roles);
    setSortRole(P2P_NAME);
}

