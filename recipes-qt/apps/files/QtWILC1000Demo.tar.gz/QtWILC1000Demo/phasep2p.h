#ifndef PHASEP2P_H
#define PHASEP2P_H

#include <QObject>
#include "common.h"
#include "p2plistitem.h"
#include "p2plistmodel.h"

class PhaseP2P : public QObject
{
    Q_OBJECT
public:
    explicit PhaseP2P(QObject *parent = 0);
    ~PhaseP2P();

signals:
    void sendInitComplete();
    void sendEventResult(QVariant event, QVariant result = "");
    void sendP2PListModel(QVariant model);

public slots:
    void receiveEvent(QString event);

private:
    void doInit();
    void doConfigureSupplicant();
    void doConfigureP2P();
    void doConfigureDHCP();
    void doSet();
    void doStop();
    void doParse();
    void doUpdate(bool dhcp);
    void doConnect();
    void doDisconnect(bool fromPeer);
    void doKillProcess();

private:
    P2PListModel mP2PListModel;

private:
    QObject *mP2PName;
    QObject *mP2PList;

private:
    State mState;
};

#endif // PHASEP2P_H
