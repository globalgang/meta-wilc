#include "aplistitem.h"

APListItem::APListItem(QString peer_mac, QString peer_name)
{
    m_mac = peer_mac;
    m_client_ip = peer_name;
}

APListItem::~APListItem()
{

}

QVariant APListItem::data(int role) const
{
    switch(role)
    {
    case AP_MAC:
        return QVariant(m_mac);
    case AP_IP:
        return QVariant(m_client_ip);
    }
    return QVariant(QString(""));
}

void APListItem::setData(const QVariant &value, int role)
{
    switch(role)
    {
    case AP_MAC:
        m_mac = value.toString();
        break;
    case AP_IP:
        m_client_ip = value.toString();
        break;
    }
    emitDataChanged();
}

