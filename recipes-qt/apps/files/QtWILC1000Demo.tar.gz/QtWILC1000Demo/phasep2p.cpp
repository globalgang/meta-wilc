#include "phasep2p.h"
#include <QProcess>
#include <iostream>

PhaseP2P::PhaseP2P(QObject *parent) : QObject(parent)
{
    mP2PListModel.clear();

    QObject::connect(this, SIGNAL(sendP2PListModel(QVariant)), parent, SLOT(receiveListModel(QVariant)));
    QObject::connect(this, SIGNAL(sendEventResult(QVariant, QVariant)), parent, SLOT(receiveEventResult(QVariant, QVariant)));

    mP2PList = parent->findChild<QObject *>("p2pListView")->findChild<QObject *>("list");
    mP2PName = parent->findChild<QObject *>("P2PModePlate")->
            findChild<QObject *>("P2PModeDeviceName");
}

PhaseP2P::~PhaseP2P()
{

}

void PhaseP2P::receiveEvent(QString event)
{
    std::cout<<"Receive P2P Event : " + event.toStdString()<<std::endl;

    if(0) {
        QString temp("P2P: * Device Info: addr fa:f0:05:f0:b2:4f primary device type 255-0050F204-0 device name 'P2P_KNG' config methods 0x248c");
        QStringList strList = temp.split(QRegExp("\\w\\w:\\w\\w:\\w\\w:\\w\\w:\\w\\w:\\w\\w"));
        foreach (QString str, strList) {
            std::cout<<str.toStdString()<<std::endl;
        }

        int start = temp.indexOf(QRegExp("[\\S]+:\\w\\w"));
        std::cout<<temp.mid(start, QString("00:00:00:00:00:00").length()).toStdString()<<std::endl;

        start = temp.indexOf("\'");
        start++;
        int last = temp.lastIndexOf("\'");
        std::cout<<QString::number(start).toStdString() + " / " + QString::number(last).toStdString()<<std::endl;
        std::cout<<temp.mid(start, last - start).toStdString()<<std::endl;
        return;
    }

    if (!event.compare("P2P")) {
        doKillProcess();

        emit sendInitComplete();
        emit sendP2PListModel(QVariant::fromValue(&mP2PListModel));

        mState = IDLE;
    } else if(!event.compare("SET")) {
        if(mState == IDLE) {
            doConfigureSupplicant();
            doConfigureP2P();
            doConfigureDHCP();

            doInit();
            doParse();
        }
        doSet();

        mState = SCAN_SET;
    } else if(!event.compare("STOP")) {
        doStop();
    } else if(!event.compare("Connect")) {
        doStop();
        doConnect();
    } else if(!event.compare("Disconnect")) {
        doDisconnect(false);
    } else {
        doUpdate(event.contains("udhcpd_parse"));
    }
}

void PhaseP2P::doInit()
{
    std::cout<<"doInit"<<std::endl;

    QProcess proc;

    proc.startDetached("/bin/sh -c "
                       "\"wpa_supplicant -Dnl80211 -ip2p0 -c/etc/temp_p2p_supplicant.conf -N -Dnl80211 -iwlan0 -c/etc/temp_wpa_supplicant.conf "
                       "-f /var/log/p2p_supplicant.log\"");
    proc.waitForFinished(10000);

    proc.start("ifconfig p2p0 192.168.0.1");
    proc.waitForFinished(10000);

    proc.startDetached("/bin/sh -c \"udhcpd -f /etc/temp_udhcpd.conf > /var/log/udhcpd.log\"");
    proc.waitForFinished(10000);

    proc.close();
}

void PhaseP2P::doConfigureSupplicant()
{
    std::cout<<"doConfigureSupplicant"<<std::endl;

    QProcess proc;

    QString supplicantConf;

    supplicantConf.append("ctrl_interface=/var/run/wpa_supplicant\n");
    supplicantConf.append("update_config=1\n");

    std::cout<<supplicantConf.toStdString()<<std::endl;

    proc.start("/bin/sh -c \"cat /dev/null > /etc/temp_wpa_supplicant.conf\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureSupplicant 1"<<std::endl;
    }

    proc.start(QString("/bin/sh -c \"echo \"\"\"%1\"\"\" > /etc/temp_wpa_supplicant.conf\"").arg(supplicantConf));
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureSupplicant 2"<<std::endl;
    }

    proc.close();
}

void PhaseP2P::doConfigureP2P()
{
    std::cout<<"doConfigureP2P"<<std::endl;

    QProcess proc;

    QString p2pConf;

    p2pConf.append("ctrl_interface=/var/run/p2p_supplicant\n");
    p2pConf.append("ap_scan=1\n");

    p2pConf.append(QString("device_name=%1\n").arg(mP2PName->property("inputText").toString()));

    p2pConf.append("device_type=1-0050F204-1\n");
    p2pConf.append("update_config=1\n");
    p2pConf.append("config_methods=virtual_push_button physical_display keypad\n");

    std::cout<<p2pConf.toStdString()<<std::endl;

    proc.start("/bin/sh -c \"cat /dev/null > /etc/temp_p2p_supplicant.conf\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureP2P 1"<<std::endl;
    }

    proc.start(QString("/bin/sh -c \"echo \"\"\"%1\"\"\" > /etc/temp_p2p_supplicant.conf\"").arg(p2pConf));
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureP2P 2"<<std::endl;
    }

    proc.close();
}

void PhaseP2P::doConfigureDHCP()
{
    std::cout<<"doConfigureDHCP"<<std::endl;

    QProcess proc;

    QString dhcpConf;

    dhcpConf.append("start 192.168.0.20\n");
    dhcpConf.append("end 192.168.0.50\n");

    dhcpConf.append("interface p2p0\n");

    dhcpConf.append("opt dns 10.168.5.38\n");
    dhcpConf.append("opt subnet 255.255.255.0\n");
    dhcpConf.append("opt router 192.168.0.1\n");
    dhcpConf.append("opt lease 86400\n");

    std::cout<<dhcpConf.toStdString()<<std::endl;

    proc.start("/bin/sh -c \"cat /dev/null > /etc/temp_udhcpd.conf\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureDHCP 1"<<std::endl;
    }

    proc.start(QString("/bin/sh -c \"echo \"\"\"%1\"\"\" > /etc/temp_udhcpd.conf\"").arg(dhcpConf));
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigureDHCP 2"<<std::endl;
    }

    proc.close();
}

void PhaseP2P::doSet()
{
    std::cout<<"doSet"<<std::endl;
    QProcess proc;
    proc.start("wpa_cli -p /var/run/p2p_supplicant p2p_find");
    proc.waitForFinished(10000);
    proc.close();
}

void PhaseP2P::doStop()
{
    std::cout<<"doStop"<<std::endl;
    QProcess proc;
    proc.start("wpa_cli -p /var/run/p2p_supplicant p2p_stop_find");
    proc.waitForFinished(10000);
    proc.close();

    emit sendEventResult("doStop");
}

void PhaseP2P::doParse()
{
    std::cout<<"doParse"<<std::endl;
    QProcess proc;
    proc.startDetached("/bin/sh -c \" tail -f /var/log/p2p_supplicant.log | "
                       //Find Peer Info & Check Connected peer
                       "grep --line-buffered -e P2P-DEVICE-FOUND -e AP-STA-CONNECTED -e AP-STA-DISCONNECTED -e P2P-PROV-DISC-PBC-REQ > "
                       "/var/log/p2p_parse.log\"");
    proc.waitForFinished(10000);

    proc.startDetached("/bin/sh -c \" tail -f /var/log/udhcpd.log | "                       
                       "grep --line-buffered -e \'Sending ACK to\' > "
                       "/var/log/udhcpd_parse.log\"");
    proc.waitForFinished(10000);

    proc.close();
}

void PhaseP2P::doUpdate(bool dhcp)
{
    std::cout<<"doUpdate"<<std::endl;
    QProcess proc;
    QString result;

    QString tempMacAddress;
    int posIndex;
    QModelIndexList indexList;

    if(dhcp) {
        std::cout<<"Add IP in dhcp process"<<std::endl;

        proc.start("tail -n 1 /var/log/udhcpd_parse.log");

        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();

            QString ipAddr = result.remove(0, QString("Sending ACK to ").length());

            if(ipAddr.isEmpty() || ipAddr.isNull()) {
                return;
            }

            mP2PListModel.item(mP2PList->property("currentIndex").toInt())->setData(ipAddr, P2P_IP);
        }
    } else {
        proc.start("tail -n 1 /var/log/p2p_parse.log");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();

            std::cout<<"doUpdate Message====================="<<std::endl;
            std::cout<<result.toStdString()<<std::endl;
            std::cout<<"==========================end Message"<<std::endl;

            if(result.contains("P2P-DEVICE-FOUND")) {
                posIndex = result.indexOf(QRegExp("[\\S]+:\\w\\w"));

                tempMacAddress = result.mid(posIndex, QString("00:00:00:00:00:00").length());

                indexList = mP2PListModel.match(
                            mP2PListModel.index(0, 0, QModelIndex()),
                            P2P_MAC,
                            tempMacAddress,
                            -1);

                if(indexList.size() == 0) {
                    int start = result.indexOf("\'");
                    int end = result.lastIndexOf("\'");

                    if(start > 0 && end > start) {
                        QString tempDeviceName = result.mid(start + 1, end - (start + 1));
                        mP2PListModel.appendRow(new P2PListItem(tempMacAddress, tempDeviceName));

                        std::cout<<"doUpdate Item : " + tempMacAddress.toStdString() + " / " + tempDeviceName.toStdString()<<std::endl;
                    }
                }
            } else if(result.contains("AP-STA-CONNECTED")) {
                posIndex = result.indexOf(QRegExp("[\\S]+:\\w\\w"));

                tempMacAddress = result.mid(posIndex, QString("00:00:00:00:00:00").length());

                indexList = mP2PListModel.match(
                            mP2PListModel.index(0, 0, QModelIndex()),
                            P2P_MAC,
                            tempMacAddress,
                            -1);

                if(indexList.size() > 0) {
                    mP2PListModel.item((indexList.at(0).row()))->setData(CONNECTED, P2P_STATUS);
                }

                emit sendEventResult("doP2PConnect", "");
            } else if(result.contains("AP-STA-DISCONNECTED")) {
                doDisconnect(true);

                posIndex = result.indexOf(QRegExp("[\\S]+:\\w\\w"));

                tempMacAddress = result.mid(posIndex, QString("00:00:00:00:00:00").length());

                indexList = mP2PListModel.match(
                            mP2PListModel.index(0, 0, QModelIndex()),
                            P2P_MAC,
                            tempMacAddress,
                            -1);

                if(indexList.size() > 0) {
                    mP2PListModel.item((indexList.at(0).row()))->setData(DISCONNECTED, P2P_STATUS);
                    mP2PListModel.item((indexList.at(0).row()))->setData("", P2P_IP);
                }
            } else if(result.contains("P2P-PROV-DISC-PBC-REQ")) {
                posIndex = result.indexOf(QRegExp("[\\S]+:\\w\\w"));

                tempMacAddress = result.mid(posIndex, QString("00:00:00:00:00:00").length());

                indexList = mP2PListModel.match(
                            mP2PListModel.index(0, 0, QModelIndex()),
                            P2P_MAC,
                            tempMacAddress,
                            -1);

                if(indexList.size() > 0) {
                    doStop();

                    std::cout<<mP2PListModel.item((indexList.at(0).row()))->data(P2P_NAME).toString().toStdString()<<std::endl;

                    //try to Connect
                    proc.start(QString("wpa_cli -p /var/run/p2p_supplicant p2p_connect %1 pbc").arg(tempMacAddress));
                    proc.waitForFinished(10000);
                }
            }
        }
    }

    proc.close();
}

void PhaseP2P::doConnect()
{
    std::cout<<"doConnect"<<std::endl;
    QProcess proc;

    int selectIndex = mP2PList->property("currentIndex").toInt();
    QString macAddr = mP2PListModel.item(selectIndex)->data(P2P_MAC).toString();

    std::cout<<"To MAC : " + macAddr.toStdString()<<std::endl;

    proc.start(QString("wpa_cli -p /var/run/p2p_supplicant p2p_connect %1 pbc").arg(macAddr));
    proc.waitForFinished(10000);

    proc.close();
}

void PhaseP2P::doDisconnect(bool fromPeer)
{
    std::cout<<"doDisconnect Request : "<<std::ends;
    std::cout<<(fromPeer ? "From Peer" : "From User")<<std::endl;
    QProcess proc;

    proc.start("wpa_cli -p /var/run/p2p_supplicant disable 0");
    proc.waitForFinished(10000);

    proc.start("wpa_cli -p /var/run/p2p_supplicant remove_network 0");
    proc.waitForFinished(10000);

    if(!fromPeer) {
        int selectIndex = mP2PList->property("currentIndex").toInt();
        mP2PListModel.item(selectIndex)->setData(DISCONNECTED, P2P_STATUS);
        mP2PListModel.item(selectIndex)->setData("", P2P_IP);
    }

    proc.close();
}

void PhaseP2P::doKillProcess()
{
    std::cout<<"doKillProcess"<<std::endl;
    QProcess proc;

    proc.start("killall udhcpd");
    proc.waitForFinished(10000);

    proc.start("killall hostapd");
    proc.waitForFinished(10000);

    proc.start("killall wpa_supplicant");
    proc.waitForFinished(10000);

    proc.start("killall tail");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/udhcpd.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/udhcpd_parse.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/p2p_supplicant.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/p2p_parse.log\"");
    proc.waitForFinished(10000);

    proc.close();
}

