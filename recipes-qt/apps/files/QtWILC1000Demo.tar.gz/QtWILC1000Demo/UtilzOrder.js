var Enum = {
    "BasePlate": 1,
    "MainMenuPlate": 10,
    "SubMenuPlate": 20,
    "DimScreenPlate": 30,
    "InputDialogPlate" : 40,
    "KeyboardPlate" : 50,
    "TopMenuPlate": 60,
}
