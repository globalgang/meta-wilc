#ifndef APLISTMODEL_H
#define APLISTMODEL_H

#include "common.h"

class APListModel : public QStandardItemModel
{
public:
    APListModel();
};

#endif // APLISTMODEL_H
