#ifndef PROCESSTHREAD
#define PROCESSTHREAD

#include <QThread>
#include <QFileSystemWatcher>
#include <QStringList>
#include <iostream>

class ProcessThread : public QThread
{
    Q_OBJECT
public:
    explicit ProcessThread(QObject* parent = 0) : QThread(parent) {
        QObject::connect(parent, SIGNAL(setPhase(QString)), this, SLOT(receivePhase(QString)));
        QObject::connect(parent, SIGNAL(sendCommand(QString)), this, SLOT(receiveCommand(QString)));
        QObject::connect(this, SIGNAL(finished()), parent, SLOT(receiveQuitSignal()));
        mWatcher = new QFileSystemWatcher();
    }

    ~ProcessThread() {
        quit();
    }

signals:
    void sendStationEvent(QString event);
    void sendAPEvent(QString event);
    void sendP2PEvent(QString event);

private:
    void setFileWatcherPath(QStringList path) {
        if(mWatcher != NULL && !path.isEmpty() && path.size() > 0) {
            if(!mPath.isEmpty() && mPath.size() > 0) {
                mWatcher->removePaths(mPath);
                QObject::disconnect(this);

                mPath.clear();
            }
            mPath << path;
            mWatcher->addPaths(mPath);
            QObject::connect(mWatcher, SIGNAL(fileChanged(QString)), this, SLOT(receiveCommand(QString)), Qt::QueuedConnection);
        }
    }

public slots:
    void receivePhase(QString phase) {
        std::cout<<"Phase : " + phase.toStdString()<<std::endl;
        if(phase.contains("STATION")) {
            mMode = STATION;
        } else if(phase.contains("AP")) {
            mMode = AP;
        } else if(phase.contains("P2P")){
            mMode = P2P;
        }

        receiveCommand(phase);        
    }

    void receiveCommand(QString command) {
        mCommand = command;
        if(!this->isRunning()) {
            std::cout<<"RunThread"<<std::endl;
            start();
        }
    }

    void receiveInitComplete() {
        if(mMode == STATION) {
            setFileWatcherPath(QStringList("/var/log/wpa_parse.log"));
        } else if(mMode == AP) {
            setFileWatcherPath(QStringList() << "/var/log/hostapd_parse.log" << "/var/log/udhcpd_parse.log");
        } else if(mMode == P2P){
            setFileWatcherPath(QStringList() << "/var/log/p2p_parse.log" << "/var/log/udhcpd_parse.log");
        }
    }

protected:
    void run(void){
        while(!mCommand.contains("QUIT")) {
            if(!mCommand.isNull() && !mCommand.isEmpty()) {
                std::cout<<"Command : " + mCommand.toStdString()<<std::endl;
                if(mMode == STATION) {
                    emit sendStationEvent(mCommand);
                } else if (mMode == AP) {
                    emit sendAPEvent(mCommand);
                } else {
                    emit sendP2PEvent(mCommand);
                }
                mCommand.clear();
            }
            msleep(100);
        }
    }

private:
    typedef enum {
        STATION = 0,
        AP,
        P2P
    } Mode;

private:
    QFileSystemWatcher *mWatcher;
    QString mCommand;
    QStringList mPath;
    Mode mMode;
};

#endif // PROCESSTHREAD

