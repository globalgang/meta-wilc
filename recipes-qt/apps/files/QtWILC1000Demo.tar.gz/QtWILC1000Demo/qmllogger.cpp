#include "qmllogger.h"
#include "iostream"

QmlLogger::QmlLogger(QObject *parent) : QObject(parent)
{
    QObject::connect(parent, SIGNAL(sendLog(QString)), this, SLOT(receiveLog(QString)));
}

QmlLogger::~QmlLogger()
{

}

void QmlLogger::receiveLog(QString log)
{
    std::cout<<"From QML : " + log.toStdString()<<std::endl;
}

