#ifndef PHASEAP_H
#define PHASEAP_H

#include <QObject>
#include "common.h"
#include "aplistitem.h"
#include "aplistmodel.h"

class PhaseAP : public QObject
{
    Q_OBJECT
public:
    explicit PhaseAP(QObject *parent = 0);
    ~PhaseAP();

signals:
    void sendInitComplete();
    void sendAPListModel(QVariant model);
    void sendEventResult(QVariant event, QVariant result = "");

public slots:
    void receiveEvent(QString event);

private:
    void doInit();
    void doConfigureAP();
    void doConfigureDHCP();
    void doSet();
    void doParse();
    void doUpdate(bool dhcp);
    void doDisconnect();
    void doKillProcess();

private:
    APListModel mAPListModel;

private:
    QObject *mAPSSID;
    QObject *mAPType;
    QObject *mAPPassword;
    QObject *mAPHWMode;
    QObject *mAPChannel;

private:
    State mState;
};

#endif // PHASEAP_H
