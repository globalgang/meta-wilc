#include "aplistmodel.h"

APListModel::APListModel()
{
    QHash<int, QByteArray> roles;
    roles[AP_MAC] = "mac";
    roles[AP_IP] = "client_ip";
    setItemRoleNames(roles);
    setSortRole(AP_IP);
}

