#include "stationlistmodel.h"

StationListModel::StationListModel()
{
    QHash<int, QByteArray> roles;
    roles[ST_SSID] = "ssid";
    roles[ST_BSSID] = "bssid";
    roles[ST_FREQUENCY] = "frequency";
    roles[ST_SIGNALS] = "signals";
    roles[ST_FLAGS] = "flags";
    roles[ST_STATUS] = "status";
    roles[ST_IP] = "ip";
    setItemRoleNames(roles);
    setSortRole(ST_SIGNALS);
}
