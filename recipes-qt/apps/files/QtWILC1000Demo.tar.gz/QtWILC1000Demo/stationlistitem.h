#ifndef STATIONLISTITEM_H
#define STATIONLISTITEM_H

#include "common.h"

class StationListItem : public QStandardItem
{
public:
    StationListItem(QString ssid, QString bssid, int frequency, int signal, QString flag);
    ~StationListItem();

protected:
    QVariant data(int role = Qt::UserRole + 1) const;
    void setData(const QVariant &value, int role = Qt::UserRole + 1);

private:
    QString m_ssid;
    QString m_bssid;
    int m_frequency;
    int m_signal;
    QString m_flag;
    bool m_status;
    QString m_ip;
};

#endif // STATIONLISTITEM_H
