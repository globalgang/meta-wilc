#include "stationlistitem.h"

StationListItem::StationListItem(QString ssid, QString bssid, int frequency, int signal, QString flag)
{
    m_ssid      = ssid;
    m_bssid     = bssid;
    m_frequency = frequency;
    m_signal    = signal;
    m_flag      = flag;
    m_status    = DISCONNECTED;
    m_ip        = "";
}

StationListItem::~StationListItem()
{

}

QVariant StationListItem::data(int role) const
{
    switch(role)
    {
    case ST_SSID:
        return QVariant(m_ssid);
    case ST_BSSID:
        return QVariant(m_bssid);
    case ST_FREQUENCY:
        return QVariant(m_frequency);
    case ST_SIGNALS:
        return QVariant(m_signal);
    case ST_FLAGS:
        return QVariant(m_flag);
    case ST_STATUS:
        return QVariant(m_status);
    case ST_IP:
        return QVariant(m_ip);
    }
    return QVariant(QString(""));
}

void StationListItem::setData(const QVariant &value, int role)
{
    switch(role)
    {
    case ST_SSID:
        m_ssid = value.toString();
        break;
    case ST_BSSID:
        m_bssid = value.toString();
        break;
    case ST_FREQUENCY:
        m_frequency = value.toInt();
        break;
    case ST_SIGNALS:
        m_signal = value.toInt();
        break;
    case ST_FLAGS:
        m_flag = value.toString();
        break;
    case ST_STATUS:
        m_status = value.toBool();
        break;
    case ST_IP:
        m_ip = value.toString();
        break;
    }
    emitDataChanged();
}

