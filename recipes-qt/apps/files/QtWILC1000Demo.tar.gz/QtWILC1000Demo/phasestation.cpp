#include "phasestation.h"
#include <QProcess>
#include <QThread>
#include <iostream>

PhaseStation::PhaseStation(QObject *parent) : QObject(parent)
{
    mStationListModel.clear();
    mSSID_Filter.setPattern("[A-Za-z0-9]");

    QObject::connect(this, SIGNAL(sendStationListModel(QVariant)), parent, SLOT(receiveListModel(QVariant)));
    QObject::connect(this, SIGNAL(sendEventResult(QVariant,QVariant)), parent, SLOT(receiveEventResult(QVariant, QVariant)));

    mStationList = parent->findChild<QObject *>("stationListView")->findChild<QObject *>("list");
    mStationPSK = parent->findChild<QObject *>("passwordPlate");
}

PhaseStation::~PhaseStation()
{

}

void PhaseStation::receiveEvent(QString event)
{
    std::cout<<"Receive Station Event : " + event.toStdString()<<std::endl;

    if(0) {
        if(1) {
            QProcess proc;
            proc.start(QString("/bin/sh -c \"cat /proc/net/arp | grep wlan0\""));
            if(proc.waitForFinished(10000)) {
                QStringList result = QString(proc.readAllStandardOutput()).split(QRegExp("\\s"));

                std::cout<<result.first().toStdString()<<std::endl;
            }
        }

        if(0) {
            QString temp = "wlan0: AP-STA-CONNECTED a0:e4:53:ca:05:8e";

            std::cout<<temp.remove(0, QString("wlan0: AP-STA-CONNECTED ").length()).toStdString()<<std::endl;

            return;
        }

        if(mStationListModel.rowCount() > 0) {
            mStationListModel.appendRow(new StationListItem("Add", "64:e5:99:a4:f6:a1", 2447, -10, "[ESS]"));
            //mStationListModel.
            mStationListModel.setSortRole(ST_SIGNALS);
            mStationListModel.sort(0, Qt::DescendingOrder);

            QModelIndexList index =
                    mStationListModel.match(
                        mStationListModel.index(
                            0, 0,
                            QModelIndex()),
                        ST_BSSID, QString("64:e5:99:a4:f6:a2"), -1);

            std::cout<<
                        index.at(0).data(ST_SIGNALS).toString().toStdString()
                    <<std::endl;

            mStationListModel.removeRow(index.at(0).row());

            return;
        }
        mStationListModel.clear();
        mStationListModel.appendRow(new StationListItem("OIC_AP", "64:e5:99:a4:f6:a2", 2447, -43, "[WPA-PSK-CCMP][ESS]"));
        mStationListModel.appendRow(new StationListItem("OIC_AP", "64:e5:99:a4:f6:a3", 2447, -10, "[WPA2-PSK-CCMP][WPS][ESS]"));
        mStationListModel.appendRow(new StationListItem("OIC_AP", "64:e5:99:a4:f6:a4", 2447, -30, "[WPA-PSK-CCMP][WPA2-PSK-CCMP][WEP][ESS]"));
        mStationListModel.appendRow(new StationListItem("OIC_AP", "64:e5:99:a4:f6:a5", 2447, -90, "[ESS]"));
        emit sendStationListModel(QVariant::fromValue(&mStationListModel));

        mStationListModel.item(0)->setData(true, ST_STATUS);
        return;
    }

    if (!event.compare("STATION")) {
        mState = IDLE;
        doKillProcess();
        doConfigure();
        doInit();
        doParse();

        emit sendInitComplete();
    } else if (!event.compare("SCAN")) {
        doScan();
        mState = SCAN_SET;
    } else if (!event.compare("Connect") || !event.compare("Password")) {
        doDisconnect();
        doConnect(!event.compare("Password"));
        mState = CONNECT;
    } else if (!event.compare("Disconnect")) {
        doDisconnect();
    } else {
        switch (mState) {
        case SCAN_SET:
            QThread::sleep(1);
            doScanResult();
            break;
        case CONNECT:
            doConnectResult();
            break;
        default:
            break;
        }
    }
}

void PhaseStation::doInit()
{
    std::cout<<"doInit"<<std::endl;

    QProcess proc;

    proc.startDetached("/bin/sh -c \"wpa_supplicant -Dnl80211 -iwlan0 -c/etc/temp_wpa_supplicant.conf -d -f /var/log/wpa_supplicant.log\"");
    if(proc.waitForFinished(10000)) {}
    proc.close();
}

void PhaseStation::doConfigure()
{
    QProcess proc;

    QString supplicantConf;

    supplicantConf.append("ctrl_interface=/var/run/wpa_supplicant\n");
    supplicantConf.append("update_config=1\n");

    std::cout<<supplicantConf.toStdString()<<std::endl;

    proc.start("/bin/sh -c \"cat /dev/null > /etc/temp_wpa_supplicant.conf\"");
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigure 1"<<std::endl;
    }

    proc.start(QString("/bin/sh -c \"echo \"\"\"%1\"\"\" > /etc/temp_wpa_supplicant.conf\"").arg(supplicantConf));
    if(!proc.waitForFinished(10000)) {
        std::cout<<"[Error] doConfigure 2"<<std::endl;
    }

    proc.close();
}

void PhaseStation::doParse()
{
    std::cout<<"doParse"<<std::endl;
    QProcess proc;
    proc.startDetached("/bin/sh -c \" tail -f /var/log/wpa_supplicant.log | "
                       "grep --line-buffered -e \'Received scan results\' -e CTRL-EVENT-CONNECTED > "
                       "/var/log/wpa_parse.log\"");
    if(proc.waitForFinished(10000)){}
    proc.close();
}

void PhaseStation::doScan()
{
    std::cout<<"doScan"<<std::endl;
    QProcess proc;
    QString result;

    proc.start("wpa_cli -p /var/run/wpa_supplicant scan");
    if(proc.waitForFinished(10000)) {
        result = proc.readAllStandardOutput();
    }
    proc.close();
}

void PhaseStation::doScanResult(bool bDummy)
{
    std::cout<<"doScanResult"<<std::endl;
    QProcess proc;
    bool bState = false;
    proc.start("wpa_cli -p /var/run/wpa_supplicant scan_result");
    if(proc.waitForFinished(10000)) {
        QString tSSID;
        QStringList tAP_LIST = QString(proc.readAllStandardOutput()).split("\n");

        bState = !tAP_LIST.isEmpty();

        if(!bDummy && bState){
            //delete "Selected interface 'wlan0'"
            tAP_LIST.removeFirst();
            //delete "bssid / frequency / signal level / flags / ssid"
            tAP_LIST.removeFirst();
        }

        mStationListModel.clear();

        if(!bDummy && bState) {
            foreach(QString tAP_DATA, tAP_LIST) {
                if(!tAP_DATA.isEmpty() && !tAP_DATA.isNull()) {
                    tSSID = tAP_DATA.split("\t").last();

                    if(tSSID.isEmpty() || tSSID.isNull() || mSSID_Filter.exactMatch(tSSID) || tSSID.length() > 38) {
                        continue;
                    } else {
                        mStationListModel.appendRow(
                                    new StationListItem(
                                        //SSID
                                        tAP_DATA.split("\t").last(),
                                        //BSSID
                                        tAP_DATA.split("\t").at(0),
                                        //Frequency
                                        tAP_DATA.split("\t").at(1).toInt(),
                                        //Signal
                                        tAP_DATA.split("\t").at(2).toInt(),
                                        //Flags
                                        tAP_DATA.split("\t").at(3)
                                        )
                                    );
                    }
                }
            }
        }
        mStationListModel.setSortRole(ST_SIGNALS);
        mStationListModel.sort(0, Qt::DescendingOrder);
        emit sendStationListModel(QVariant::fromValue(&mStationListModel));
    }
    if(!bDummy) {
        if(bState && mStationListModel.rowCount() > 0) {
            emit sendEventResult(QVariant("doScanResult"), QVariant("Success"));
        } else {
            emit sendEventResult(QVariant("doScanResult"), QVariant("Fail"));
        }
    }
    proc.close();
}

void PhaseStation::doConnect(bool bPassword)
{
    std::cout<<"doConnect : password = " + QString(bPassword ? "true" : "false").toStdString()<<std::endl;
    QProcess proc;
    QString result;
    QString tSSID;
    QString tPSK;
    bool bState = false;

    if (mStationList != NULL) {
        bState = true;
        int index = mStationList->property("currentIndex").toInt();

        if(mStationListModel.rowCount() > index) {
            tSSID    = mStationListModel.item(index)->data().toString();
            tPSK     = mStationPSK->property("passwordStr").toString();
        } else {
            bState = false;
        }
    }

    if(bState) {
        bState = false;
        proc.start("wpa_cli -p /var/run/wpa_supplicant ap_scan 1");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();
            if(result.contains("OK")) {
                bState = true;
            } else {
                result = "ap_scan fail\n";
                result.append(proc.readAllStandardOutput());
                std::cout<<result.toStdString()<<std::endl;
            }
        }
    }

    if(bState) {
        bState = false;
        proc.start("wpa_cli -p /var/run/wpa_supplicant add_network");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();
            if(result.contains("0")) {
                bState = true;
            } else {
                result = "add_network fail\n";
                result.append(proc.readAllStandardOutput());
                std::cout<<result.toStdString()<<std::endl;
            }
        }
    }

    if(bState) {
        bState = false;
        proc.start(QString("wpa_cli -p /var/run/wpa_supplicant set_network 0 ssid \"\"\"%1\"\"\"")
                   .arg(tSSID));
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();
            if(result.contains("OK")) {
                bState = true;
            } else {
                result = "set_network ssid fail\n";
                result.append(proc.readAllStandardOutput());
                std::cout<<result.toStdString()<<std::endl;
            }
        }
    }

    if(bState) {
        bState = false;
        if(bPassword) {
            proc.start(QString("wpa_cli -p /var/run/wpa_supplicant set_network 0 psk \"\"\"%1\"\"\"")
                       .arg(tPSK));
        } else {
            proc.start(QString("wpa_cli -p /var/run/wpa_supplicant set_network 0 key_mgmt NONE"));
        }
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();
            if(result.contains("OK")) {
                bState = true;
            } else {
                result = "set_network key fail\n";
                result.append(proc.readAllStandardOutput());
                std::cout<<result.toStdString()<<std::endl;
            }
        }
    }

    if(bState) {
        bState = false;
        proc.start("wpa_cli -p /var/run/wpa_supplicant select_network 0");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();
            if(result.contains("OK")) {
                bState = true;
            } else {
                result = "select_network fail\n";
                result.append(proc.readAllStandardOutput());
                std::cout<<result.toStdString()<<std::endl;
            }
        }
    }

    if(bState) {
        emit sendEventResult(QVariant("doConnect"), QVariant(""));
    } else {
        emit sendEventResult(QVariant("doConnect"), QVariant("Fail"));
    }
    proc.close();
}

void PhaseStation::doConnectResult()
{
    std::cout<<"doConnectResult"<<std::endl;
    QProcess proc;
    QString result;
    bool bState = false;

    proc.start("wpa_cli -p /var/run/wpa_supplicant status");
    if(proc.waitForFinished(10000)) {
        result = proc.readAllStandardOutput();
        if(result.contains("COMPLETED")) {
            bState = true;
        }
    }
    std::cout<<"Connect : " + QString(bState ? "OK" : "Fail").toStdString()<<std::endl;

    if(bState) {
        bState = false;

        proc.start("udhcpc -i wlan0");
        if(proc.waitForFinished(10000)) {
            result = proc.readAllStandardOutput();
            if(result.contains("obtained")) {
                bState = true;
                std::cout<<"==== DHCP ====\n" + result.toStdString()<<std::endl;

                result = result.mid(result.indexOf("Lease of") + QString("Lease of ").length());
                result = result.left(result.indexOf(" obtained"));

                mStationListModel.item(mStationList->property("currentIndex").toInt())->setData(CONNECTED, ST_STATUS);
                mStationListModel.item(mStationList->property("currentIndex").toInt())->setData(result, ST_IP);

                emit sendEventResult(QVariant("doConnectResult"), QVariant("Success"));
            }
        }
    }

    proc.close();
}

void PhaseStation::doDisconnect()
{
    std::cout<<"doDisconnect"<<std::endl;
    QProcess proc;

    proc.start("wpa_cli -p /var/run/wpa_supplicant disable 0");
    if(proc.waitForFinished(10000)) {}

    proc.start("wpa_cli -p /var/run/wpa_supplicant remove_network 0");
    if(proc.waitForFinished(10000)) {}

    //emit sendEventResult(QVariant("doDisconnect"), QVariant(""));
    proc.close();

    for(int i=0; i<mStationListModel.rowCount(); i++) {
        if(mStationListModel.item(i)->data(ST_STATUS).toBool()) {
            mStationListModel.item(i)->setData(DISCONNECTED, ST_STATUS);
            mStationListModel.item(i)->setData("", ST_IP);
        }
    }
}

void PhaseStation::doKillProcess()
{
    std::cout<<"doKillProcess"<<std::endl;
    QProcess proc;

    proc.start("killall udhcpd");
    proc.waitForFinished(10000);

    proc.start("killall hostapd");
    proc.waitForFinished(10000);

    proc.start("killall wpa_supplicant");
    proc.waitForFinished(10000);

    proc.start("killall tail");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/wpa_supplicant.log\"");
    proc.waitForFinished(10000);

    proc.start("/bin/sh -c \"cat /dev/null > /var/log/wpa_parse.log\"");
    proc.waitForFinished(10000);

    proc.close();
}
