function blendColors(s_color, d_color, p) {
    return Qt.tint(s_color, adjustAlpha(d_color, p));
}

function adjustAlpha(color, a) {
    return Qt.rgba(color.r, color.g, color.b, a);
}
