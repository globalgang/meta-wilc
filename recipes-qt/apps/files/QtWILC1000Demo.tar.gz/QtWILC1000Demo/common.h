#ifndef COMMON
#define COMMON

#include <QStandardItemModel>
#include <QStandardItem>
#include <QVariant>

enum {
    //Station
    ST_SSID = Qt::UserRole + 1,
    ST_BSSID,
    ST_FREQUENCY,
    ST_SIGNALS,
    ST_FLAGS,
    ST_STATUS,
    ST_IP,
    //AP
    AP_MAC,
    AP_IP,
    //P2P
    P2P_MAC,
    P2P_NAME,
    P2P_IP,
    P2P_STATUS,
};

enum {
    DISCONNECTED = false,
    CONNECTED,
};

typedef enum {
    IDLE,
    SCAN_SET,
    SCAN_SET_COMP,
    CONNECT,
    CONNECT_COMP,
    DISCONNECT,
    DISCONNECT_COMP,
} State;

#endif // COMMON

