#include "p2plistitem.h"

P2PListItem::P2PListItem(QString peer_mac, QString peer_name)
{
    m_peer_mac = peer_mac;
    m_peer_name = peer_name;
    m_peer_ip = "";
    m_status = false;
}

P2PListItem::~P2PListItem()
{

}

QVariant P2PListItem::data(int role) const
{
    switch(role)
    {
    case P2P_MAC:
        return QVariant(m_peer_mac);
    case P2P_NAME:
        return QVariant(m_peer_name);
    case P2P_IP:
        return QVariant(m_peer_ip);
    case P2P_STATUS:
        return QVariant(m_status);
    }
    return QVariant(QString(""));
}

void P2PListItem::setData(const QVariant &value, int role)
{
    switch(role)
    {
    case P2P_MAC:
        m_peer_mac = value.toString();
        break;
    case P2P_NAME:
        m_peer_name = value.toString();
        break;
    case P2P_IP:
        m_peer_ip = value.toString();
        break;
    case P2P_STATUS:
        m_status = value.toBool();
        break;
    }
    emitDataChanged();
}

