#include "qtquick1applicationviewer.h"
#include <QApplication>
#include <QDeclarativeItem>

#include "qmllogger.h"
#include "processthread.h"
#include "phasestation.h"
#include "phaseap.h"
#include "phasep2p.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QtQuick1ApplicationViewer viewer;
    viewer.addImportPath(QLatin1String("modules"));
    viewer.setOrientation(QtQuick1ApplicationViewer::ScreenOrientationAuto);
    viewer.setMainQmlFile(QLatin1String("qrc:/main.qml"));
    viewer.showExpanded();

    QObject *rootObject = viewer.rootObject();

    QmlLogger *mLogger = new QmlLogger(rootObject);
    ProcessThread *mThread = new ProcessThread(rootObject);
    PhaseStation *mStation = new PhaseStation(rootObject);
    PhaseAP *mAP = new PhaseAP(rootObject);
    PhaseP2P *mP2P = new PhaseP2P(rootObject);

    QObject::connect(mThread, SIGNAL(sendStationEvent(QString)), mStation, SLOT(receiveEvent(QString)));
    QObject::connect(mThread, SIGNAL(sendAPEvent(QString)), mAP, SLOT(receiveEvent(QString)));
    QObject::connect(mThread, SIGNAL(sendP2PEvent(QString)), mP2P, SLOT(receiveEvent(QString)));

    QObject::connect(mStation, SIGNAL(sendInitComplete()), mThread, SLOT(receiveInitComplete()));
    QObject::connect(mAP, SIGNAL(sendInitComplete()), mThread, SLOT(receiveInitComplete()));
    QObject::connect(mP2P, SIGNAL(sendInitComplete()), mThread, SLOT(receiveInitComplete()));

    return app.exec();
}
